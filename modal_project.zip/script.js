// Obtener referencias
const abrirModalBtn = document.getElementById("abrirModalBtn");
const cerrarModalBtn = document.getElementById("cerrarModalBtn");
const modalOverlay = document.getElementById("modalOverlay");

// Función para abrir el modal
abrirModalBtn.addEventListener("click", () => {
  modalOverlay.classList.add("visible");
});

// Función para cerrar el modal
cerrarModalBtn.addEventListener("click", () => {
  modalOverlay.classList.remove("visible");
});

// Bonus: cerrar modal al hacer clic en el overlay (fondo oscuro)
modalOverlay.addEventListener("click", (e) => {
  if (e.target === modalOverlay) {
    modalOverlay.classList.remove("visible");
  }
});
